<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Check_api extends CI_Controller {

	public function index()
	{

		
		$this->load->view('demo_form');
		
	}
}


?>